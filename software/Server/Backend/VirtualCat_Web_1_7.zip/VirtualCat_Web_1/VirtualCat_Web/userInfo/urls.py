
from django.urls import path

urlpatterns = [
    #http://域名（ip:端口）/login/login
    
]
